# 说明


这个项目主要用于练习springboot3 如何打包成docker镜像，并且启动以及后期的运维

## 项目组成
* web应用
* redis 单实例
* nginx 做前端反向代理

## 相关的知识点
1. docker 单层镜像打包
2. docker 分层镜像打包
3. docker 项目运行
4. docker项目关闭
5. docker打包生成的镜像以及容器的创建和删除
6. docker镜像多版本控制

## 源码探究
### docker 单jar包文件的启动
### docker 多jar包文件的启动
### docker-compose 依赖的jar包架构 


