package com.study.dockerDemo.biz.impl.base;


import com.study.dockerDemo.biz.base.ValidateBiz;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

/**
 *
 *
 * @author lipf
 * @since 2023/7/5 23:31
 */
@Service
public class ValidateBizByEnv implements ValidateBiz {

    private static final Logger log = LoggerFactory.getLogger(ValidateBizByEnv.class);

    @Autowired
    private Environment environment;


    /**
     * 获取当前系统运行级别，dev，test，prod
     *
     * @author lipf
     * @since 2023/7/5 23:30
     */
    @Override
    public String currentEnv() {
        String envLevel = environment.getProperty("app.env");
        log.info("通过Environment 变量获取当前系统运行级别：[{}]",envLevel);
        return envLevel;
    }
}
