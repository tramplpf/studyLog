package com.study.dockerDemo.biz.base;

/**
 *
 *
 * @author lipf
 * @since 2023/7/5 23:29
 */
public interface ValidateBiz {

    /**
     * 获取当前系统运行级别，dev，test，prod
     *
     * @author lipf
     * @since 2023/7/5 23:30
     */
    String currentEnv();

}
