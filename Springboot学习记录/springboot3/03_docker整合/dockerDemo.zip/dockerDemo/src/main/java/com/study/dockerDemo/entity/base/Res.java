package com.study.dockerDemo.entity.base;

import java.io.Serializable;

/**
 * 前后端交互的公共接口
 *
 * @author lipf
 * @since 2023/7/5 23:20
 */
public class Res<T> implements Serializable {


    public static final String SUCCESS_T = "200";

    public static final String SUCCESS_F = "500";

    /**
     * 返回消息
     */
    private String rmsg;

    /**
     * 返回消息吗
     */
    private String rCode;

    /**
     * 返回数据
     */
    private T data;

    /**
     * 返回数据的记录数
     */
    private long count;

    /**
     * 是否操作成功，或者校验成功
     *
     * @author lipf
     * @since 2023/7/5 23:26
     */
    public boolean isSuccess(){
        return Res.SUCCESS_T.equals(this.rCode);
    }

    /**
     * 是否操作失败
     *
     * @author lipf
     * @since 2023/7/5 23:27
     */
    public boolean isFail(){
        return !isSuccess();
    }

    public static Res ok(){
        Res res = new Res<>();
        res.rCode = Res.SUCCESS_T;
        return res;
    }

    public static Res fail(){
        Res res = new Res<>();
        res.rCode = Res.SUCCESS_F;
        return res;
    }

    public Res<T> Res(String rCode){
        Res<T> res = new Res<T>();
        res.rCode = rCode;
        return res;
    }

    public Res() {
    }

    public String getRmsg() {
        return rmsg;
    }

    public void setRmsg(String rmsg) {
        this.rmsg = rmsg;
    }

    public String getrCode() {
        return rCode;
    }

    public void setrCode(String rCode) {
        this.rCode = rCode;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }
}
