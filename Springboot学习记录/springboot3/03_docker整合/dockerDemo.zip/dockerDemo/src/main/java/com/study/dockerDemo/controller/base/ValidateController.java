package com.study.dockerDemo.controller.base;

import cn.hutool.core.util.StrUtil;
import com.study.dockerDemo.biz.base.ValidateBiz;
import com.study.dockerDemo.entity.base.Res;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 *
 * @author lipf
 * @since 2023/7/5 23:19
 */
@RestController
public class ValidateController {


    @Autowired
    private ValidateBiz validateBiz;

    /**
     * 获取当前系统运行环境
     *
     * curl http://127.0.0.1:8082/api/v1/base/currentEnv
     * @return dev，test，prod
     * @author lipf
     * @since 2023/7/5 23:29
     */
    @GetMapping("/api/v1/base/currentEnv")
    Res<String> currentEnv(){
        String s = validateBiz.currentEnv();
        Res res;
        if(StrUtil.isNotBlank(s)){
            res = Res.ok();
            res.setData(s);
            return res;
        }
        return Res.fail();
    }
}
