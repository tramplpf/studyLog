package com.study.dockerDemo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *
 * 
 * @author lipf
 * @since 2023/7/5 23:15
 */
@SpringBootApplication
public class DockerDemoApplication {

	private static final Logger log = LoggerFactory.getLogger(DockerDemoApplication.class);

	public static void main(String[] args) {
		log.info("sprig Boot 3 项目启动...");
		long startTime = System.currentTimeMillis();
		SpringApplication.run(DockerDemoApplication.class, args);
		log.info("Spring Boot 3 项目启动完成。耗时[{}]ms",System.currentTimeMillis() - startTime);
	}

}
