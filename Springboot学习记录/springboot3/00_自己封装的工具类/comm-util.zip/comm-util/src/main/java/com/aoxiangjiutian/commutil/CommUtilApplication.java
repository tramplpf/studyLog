package com.aoxiangjiutian.commutil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommUtilApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommUtilApplication.class, args);
	}

}
