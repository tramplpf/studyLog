package com.aoxiangjiutian.commutil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommUtilApplicationTests {

	@Test
	void contextLoads() {
	}

}
