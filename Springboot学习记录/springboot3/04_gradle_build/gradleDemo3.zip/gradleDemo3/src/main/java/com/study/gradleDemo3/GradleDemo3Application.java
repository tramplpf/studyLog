package com.study.gradleDemo3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GradleDemo3Application {

	public static void main(String[] args) {
		SpringApplication.run(GradleDemo3Application.class, args);
	}

}
