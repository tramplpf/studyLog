package com.study.gradleDemo3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradleDemo3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
