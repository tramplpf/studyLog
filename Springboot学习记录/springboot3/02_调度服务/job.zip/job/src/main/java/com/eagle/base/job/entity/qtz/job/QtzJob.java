package com.eagle.base.job.entity.qtz.job;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lipf
 * @since 2023/6/19 10:45
 */
@Schema(name = "调度任务对应的实体")
public class QtzJob implements Serializable {

    /**
     * 序号
     */
    @Schema(name = "tid",title = "序号", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    private Long tid;

    /**
     * 创建日期
     */
    @Schema(name = "创建日期",description = "yyyy-mm-dd 格式")
    private String createDate;

    /**
     * 创建时间
     */
    @Schema(name = "创建时间")
    private Date createTime;


    public Long getTid() {
        return tid;
    }

    public void setTid(Long tid) {
        this.tid = tid;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
