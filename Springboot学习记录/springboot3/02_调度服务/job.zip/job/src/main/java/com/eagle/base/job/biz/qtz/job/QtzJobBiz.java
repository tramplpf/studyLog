package com.eagle.base.job.biz.qtz.job;


import com.eagle.base.job.entity.base.comm.Res;
import com.eagle.base.job.entity.qtz.job.QtzJob;

import java.util.List;

/**
 *
 *
 * @author lipf
 * @since 2023/6/19 10:32
 */
public interface QtzJobBiz {

    /**
     * 根据查询条件查询满足条件的调度任务,支持分页
     *
     * @param qtzCode 调度代码
     * @param qtzName 调度名称
     * @param meme 备注
     * @param pageNo 分页参数 第几页
     * @param pageSize 分页参数， 每页多少条数据
     * @author lipf
     * @since 2023/6/19 10:50
     */
    public Res<List<QtzJob>> queryQtzJobs(String qtzCode, String qtzName, String meme, int pageNo, int pageSize);

    /**
     * 根据查询条件查询满足条件的调度任务
     *
     * @param qtzCode 调度代码
     * @param qtzName 调度名称
     * @param meme 备注
     * @author lipf
     * @since 2023/6/19 10:50
     */
    List<QtzJob> queryQtzJobs(String qtzCode, String qtzName, String meme);

}
