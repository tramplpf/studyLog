package com.eagle.base.job.controller.qtz.job;

import com.eagle.base.job.biz.qtz.job.QtzJobBiz;
import com.eagle.base.job.entity.base.comm.Res;
import com.eagle.base.job.entity.qtz.job.QtzJob;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 调度的Job
 *
 * @author lipf
 * @since 2023/6/19 10:29
 */
@RestController
@Tag(name = "调度任务相关的接口")
public class QtzJobController {

    private QtzJobBiz qtzJobBiz;

    /**
     * 根据调度代码查询满足条件的调度任务
     *   curl http://127.0.0.1:8081/api/v1/job/qtz/queryQtzJobs
     * @param memo 备注
     * @param qtzCode 调度代码
     * @param qtzName 调度名称
     * @author lipf
     * @since 2023/6/19 10:47
     */
    @Operation(summary = "通过查询条件查询系统支持的调度任务",description = "支持查询正在运行以及未运行的调度任务")
    @GetMapping("/api/v1/job/qtz/queryQtzJobs")
    @ApiResponse(description="满足条件的调度任务",responseCode="200")
    @Parameter(name = "qtzCode", description = "调度代码")
    @Parameter(name = "qtzName", description = "调度名称")
    @Parameter(name = "memo", description = "备注")
    public Res<List<QtzJob>> queryQtzJobs(@RequestParam(required = false) String qtzCode,
                                          @RequestParam(required = false) String qtzName,
                                          @RequestParam(required = false) String memo){
        return   qtzJobBiz.queryQtzJobs(qtzCode,qtzName, memo,1,10);
    }


    @Autowired
    public void setQtzJobBiz(QtzJobBiz qtzJobBiz) {
        this.qtzJobBiz = qtzJobBiz;
    }
}
