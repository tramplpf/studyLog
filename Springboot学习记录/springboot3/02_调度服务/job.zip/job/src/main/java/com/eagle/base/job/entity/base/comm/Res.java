package com.eagle.base.job.entity.base.comm;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 *
 * @author lipf
 * @since 2023/6/19 10:35
 */
@Schema(name = "前后端对接交互的接口定义")
public class Res<T> {

    /**
     * 操作是否成功
     */
    @Schema(name = "success",description = "操作是否成功")
    private boolean success;

    /**
     * 返回值的编码
     */
    @Schema(name = "rCode", description = "返回值编码")
    private String rCode;

    /**
     * 返回的提示信息
     */
    @Schema(description = "返回值提示信息")
    private String rMsg;

    /**
     * 查询记录数
     */
    @Schema(description = "查询记录数")
    private long count;

    /**
     * 返回的数据
     */
    @Schema(description = "返回的数据")
    private T data;


    /**
     * 构造函数
     */
    public Res(){

    }

    public Res(boolean success, String rCode, String rMsg, T data) {
        this.success = success;
        this.rCode = rCode;
        this.rMsg = rMsg;
        this.data = data;
    }

    /**
     * 返回一个操作成功的对象
     *
     * @author lipf
     * @since 2023/6/19 10:39
     */
    public static Res<String> ok(String msg){
        Res<String> res = new Res<>();
        res.setSuccess(true);
        res.setrMsg(msg);
        res.setData(msg);
        return res;
    }

    /**
     * 返回一个操作失败的对象
     *
     * @author lipf
     * @since 2023/6/19 10:43
     */
    public static Res<String> fail(String msg){
        Res<String> res = new Res<>();
        res.setSuccess(false);
        res.setrMsg(msg);
        res.setData(msg);
        return res;
    }


    /**
     * 判断操作是否异常，需要返回
     *   例如，校验不通过等
     *
     * @author lipf
     * @since 2023/6/19 10:43
     */
    public boolean isFail(){
        return !isSuccess();
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getrCode() {
        return rCode;
    }

    public void setrCode(String rCode) {
        this.rCode = rCode;
    }

    public String getrMsg() {
        return rMsg;
    }

    public void setrMsg(String rMsg) {
        this.rMsg = rMsg;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }
}
