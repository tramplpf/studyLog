package com.eagle.base.job.util;

import java.time.LocalDate;
import java.util.Date;

/**
 * 时间日期相关的工具类
 *
 * @author lipf
 * @since 2023/6/20 11:02
 */
public class DateUtil extends cn.hutool.core.date.DateUtil {

    private DateUtil(){
        throw new IllegalArgumentException("DateUtil工具类不能实例化");
    }

    /**
     * 获取系统的当前时间，含时分秒
     *
     * @author lipf
     * @since 2023/6/20 11:06
     */
    public static Date currDate(){
        return new Date();
    }



    /**
     * 获取系统的当前日期
     *
     * @return 例如： 2023-06-20
     * @author lipf
     * @since 2023/6/20 11:08
     */
    public static String currD() {
        LocalDate now = LocalDate.now();
        return now.toString();
    }
}
