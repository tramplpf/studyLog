package com.eagle.base.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobApplication {

	private static final Logger log = LoggerFactory.getLogger(JobApplication.class);

	/**
	 * 项目的启动类
	 *
	 * @author lipf
	 * @since 2023/6/20 21:26
	 */
	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		log.info("Job微服务开启启动...");
		try{
			SpringApplication.run(JobApplication.class, args);
			long costTime = System.currentTimeMillis() - startTime;
			log.info("Job为服务器启动完成，耗时[{}]ms",costTime);
		}catch (Exception e){
			long costTime = System.currentTimeMillis() - startTime;
			log.info("Job为服务器启动异常，耗时[{}]ms",costTime,e);
		}

	}

}
