package com.eagle.base.job.util;

/**
 * 集合相关的工具类
 *
 * @author lipf
 * @since 2023/6/20 11:16
 */
public class CollUtil extends cn.hutool.core.collection.CollUtil {


}
