package com.eagle.base.job.biz.impl.qtz.job;

import com.eagle.base.job.biz.qtz.job.QtzJobBiz;
import com.eagle.base.job.entity.base.comm.Res;
import com.eagle.base.job.entity.qtz.job.QtzJob;
import com.eagle.base.job.util.CollUtil;
import com.eagle.base.job.util.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * 
 * @author lipf
 * @since 2023/6/19 10:32
 */
@Service
public class QtzJobBizImpl implements QtzJobBiz {

    private static final Logger log = LoggerFactory.getLogger(QtzJobBiz.class);

    /**
     * 根据查询条件查询满足条件的调度任务
     *
     * @param qtzCode  调度代码
     * @param qtzName  调度名称
     * @param meme     备注
     * @param pageNo   分页参数 第几页
     * @param pageSize 分页参数， 每页多少条数据
     * @author lipf
     * @since 2023/6/19 10:50
     */
    @Override
    public Res<List<QtzJob>> queryQtzJobs(String qtzCode, String qtzName, String meme, int pageNo, int pageSize) {
        // TODO 分页
        log.info("根据查询条件查询调度任务：qtzCode = [{}], qtzName = [{}], memo = [{}], pageNo = [{}], pageSize = [{}]",
                qtzCode, qtzName, meme, pageNo, pageSize);
        List<QtzJob> qtzJobs = new ArrayList<>();
        QtzJob qtz = new QtzJob();
        qtz.setTid(1L);
        qtz.setCreateTime(DateUtil.currDate());
        qtz.setCreateDate(DateUtil.currD());
        qtzJobs.add(qtz);
        Res<List<QtzJob>> res = new Res<>();
        res.setSuccess(true);
        res.setData(qtzJobs);
        res.setCount(CollUtil.size(qtzJobs));
        return res;
    }

    /**
     * 根据查询条件查询满足条件的调度任务
     *
     * @param qtzCode 调度代码
     * @param qtzName 调度名称
     * @param meme    备注
     * @author lipf
     * @since 2023/6/19 10:50
     */
    @Override
    public List<QtzJob> queryQtzJobs(String qtzCode, String qtzName, String meme) {
        return null;
    }
}
