package com.eagle.base.job.config.knife4j;

import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Knife4j 配置类
 *
 * @author lipf
 * @since 2023/6/20 21:10
 */
@Configuration
public class Knife4jConfig {

    private static final Logger log = LoggerFactory.getLogger(Knife4jConfig.class);


    /**
     * 配置多个Docket的时候，使用下面的两段代码
     * 如果只有一个Docket， 直接在配置文件中添加如下配置：
     *    springdoc.packagesToScan=package1, package2
     *    springdoc.pathsToMatch=/v1, /api/balance/**
     */
//    @Bean
//    public GroupedOpenApi publicApi() {
//        return GroupedOpenApi.builder()
//                .group("springshop-public")
//                .pathsToMatch("/public/**")
//                .build();
//    }
//    @Bean
//    public GroupedOpenApi adminApi() {
//        return GroupedOpenApi.builder()
//                .group("springshop-admin")
//                .pathsToMatch("/admin/**")
//                .addOpenApiMethodFilter(method -> method.isAnnotationPresent(Admin.class))
//                .build();
//    }


    /**
     * 配置OpenApi， 配置的信息会显示在doc.html 主页介绍中
     *
     * @author lipf
     * @since 2023/6/20 21:16
     */
    @Bean
    public OpenAPI springShopOpenAPI() {
        log.info("开始配置Knife的OpenAPI...");
        OpenAPI openAPI = new OpenAPI()
                .info(new Info().title("调度框架的后台服务")
                        .description("调度相关的功能整合到这个项目中")
                        .version("v1.0")
                        .license(new License().name("Apache 2.0").url("http://springdoc.org")))
                .externalDocs(new ExternalDocumentation()
                        .description("调度框架项目以及接口的详细说明")
                        .url("http://127.0.0.1:8081"));
        log.info("配置Knife4j的OpenApi完成.");
        return openAPI;
    }

}