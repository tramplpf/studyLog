# 项目介绍

该项目是调度任务相关的一个服务，用于联系Quartz框架的相关知识。 

## 前后端接口 
前后端接口使用knife4j 进行接口管理   
http://127.0.0.1:8081/doc.html


通过如下地址查看生成的接口文档
    http://127.0.0.1:8081/v3/api-docs

参考资料
https://blog.csdn.net/javaDeveloper2010/article/details/129119489





