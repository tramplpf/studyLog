Starts a cluster via the discovery service locally. Useful for testing.
