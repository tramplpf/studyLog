
"""
学习python语法的模块
需求： math模块下额度sqrt（）开平方

python支持的五种导入模块的方法
"""

# 方法一
#import math
#print(math.sqrt(9))

# 方法二
#import math as math2
#print(math2.sqrt(9))

# 方法三
#from math import sqrt
#print(sqrt(9))

# 方法四
#from math import * 
#print(sqrt(9))

# 方法五
#from math import sqrt as aa
#print(aa(9))

# 调用自定义的模块
from my_module1 import testA;
testA(1,5)

import my_module1
my_module1.testA(1,7)

# 查看模块的搜索顺序
import sys
print("查看模块的搜索顺序")
print(sys.path)
print(f"分别查看每个搜索路径.一共有[{len(sys.path)}]个搜索路径")
path_list = sys.path
for item in path_list:
    print(item)

# 模块文件中的__all__
print("模块文件中的__all__")
from my_module2 import * 

import my_module2 as module2
testB()

testC()

print(module2.__all__)

print("不在__all__变量中的方法无法被直接使用，但是可以通过模块名.方法名 的方式来进行调用")
#testD()

module2.testD()


## 导入包
print('导入包')
#import pkg01
#pkg01.module01.info_msg()
#pkg01.module02.info_msg()

from pkg01 import * 
module01.info_msg()
module02.info_msg()

