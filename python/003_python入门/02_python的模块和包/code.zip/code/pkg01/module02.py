print(2)

def info_msg():
    print("module02")
