print(1)

def info_msg():
    print("module01")
