"""
含有__all__变量的模块
如果一个模块文件中有__all__变量，当使用 from xxx import * 导入时，只能导入这个列表中的元素
"""

__all__ = [
"testB",
"testC"
]

def testD():
    print('testD')

def testC():
    print('testC')

def testB():
    print('testB')


