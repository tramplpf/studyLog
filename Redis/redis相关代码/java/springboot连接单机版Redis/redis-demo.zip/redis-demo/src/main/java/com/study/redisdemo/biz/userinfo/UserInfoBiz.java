package com.study.redisdemo.biz.userinfo;

import com.study.redisdemo.entity.Res;
import com.study.redisdemo.entity.userinfo.UserInfo;

import java.util.List;

/**
 *
 * 
 * @author 
 * @date 2022/12/6 12:02
 * @version 1.0
 */
public interface UserInfoBiz {

    /**
     * 查询所有的用户信息
     *
     * @author
     * @date 2022/12/6 11:58
     * @version 1.0
     */
    List<UserInfo> queryAllUserInfos();

    /**
     * 保存所有的用户信息到Redis
     *
     * @author
     * @date 2022/12/6 12:39
     * @version 1.0
     */
    Res<String> saveAllUserInfo2Redis();
}
