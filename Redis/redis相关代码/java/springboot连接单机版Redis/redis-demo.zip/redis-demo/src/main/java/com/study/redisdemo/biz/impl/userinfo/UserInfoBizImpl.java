package com.study.redisdemo.biz.impl.userinfo;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONUtil;
import com.study.redisdemo.biz.userinfo.UserInfoBiz;
import com.study.redisdemo.entity.Res;
import com.study.redisdemo.entity.userinfo.UserInfo;
import com.study.redisdemo.service.userinfo.UserInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 *
 *
 * @author
 * @date 2022/12/6 11:56
 * @version 1.0
 */
@Service
public class UserInfoBizImpl implements UserInfoBiz {

    private static final Logger log = LoggerFactory.getLogger(UserInfoBizImpl.class);

    private UserInfoService userInfoService;
    private RedisTemplate<String, String> redisTemplate;

    /**
     * 查询所有的用户信息
     *
     * @author
     * @date 2022/12/6 11:58
     * @version 1.0
     */
    @Override
    public List<UserInfo> queryAllUserInfos() {
        List<UserInfo> userInfos = userInfoService.queryAllUserInfos();
        log.info("查询所有的用户信息，数量[{}]", CollUtil.size(userInfos));
        return userInfos;
    }

    /**
     * 保存所有的用户信息到Redis
     *
     * @author
     * @date 2022/12/6 12:39
     * @version 1.0
     */
    @Override
    public Res<String> saveAllUserInfo2Redis() {
        List<UserInfo> userInfos = this.queryAllUserInfos();
        if(CollUtil.isEmpty(userInfos)){
            log.info("从数据库中查询到的用户信息为空");
            Res<String> res = new Res<>();
            res.setData("从db中查询出的用户信息为空");
            return res;
        }
        //redisTemplate.opsForList().set("userinfo",0, JSONUtil.toJsonPrettyStr(userInfos));
        redisTemplate.opsForSet().add("userinfo:all",JSONUtil.toJsonStr(userInfos));

        for (UserInfo userInfo : userInfos) {
            String key = "userinfo::" + userInfo.getId();
            redisTemplate.opsForValue().set(key,JSONUtil.toJsonPrettyStr(userInfo));
            // 设置过期时间为3分钟
            redisTemplate.expire(key,3, TimeUnit.MINUTES);
        }
        Res<String> res = new Res<>();
        res.setData("将所有信息保存到redis中完成");
        return res;
    }

    @Autowired
    public void setUserInfoService(UserInfoService userInfoService) {
        this.userInfoService = userInfoService;
    }

    @Autowired
    public void setRedisTemplate(RedisTemplate<String, String> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }
}
