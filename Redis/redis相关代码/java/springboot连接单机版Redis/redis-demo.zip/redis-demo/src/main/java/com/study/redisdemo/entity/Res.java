package com.study.redisdemo.entity;

/**
 * 整个系统公共的响应对象
 *
 * @author
 * @date 2022/12/6 12:37
 * @version 1.0
 */
public class Res<T> {

    private String rmsg;

    private String rCode;

    private T data;

    public String getRmsg() {
        return rmsg;
    }

    public void setRmsg(String rmsg) {
        this.rmsg = rmsg;
    }

    public String getrCode() {
        return rCode;
    }

    public void setrCode(String rCode) {
        this.rCode = rCode;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
