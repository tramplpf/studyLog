package com.study.redisdemo.mapper.userinfo;

import com.study.redisdemo.entity.userinfo.UserInfo;

import java.util.List;

/**
 *
 * 
 * @author 
 * @date 2022/12/6 12:07
 * @version 1.0
 */
public interface UserInfoMapper {
    
    /**
     * 查询所有的用户信息
     * 
     * @author 
     * @date 2022/12/6 11:59
     * @version 1.0
     */
    List<UserInfo> queryAllUserInfos();
    
}
