package com.study.redisdemo;

import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 测试Redis相关的内容
 *
 * @author
 * @date 2022/12/6 01:12
 * @version 1.0
 */
@SpringBootApplication
@MapperScan(basePackages = "com.study.redisdemo.mapper")
public class RedisDemoApplication {

	private static final Logger log = LoggerFactory.getLogger(RedisDemoApplication.class);

	/**
	 *
	 * 
	 * @author 
	 * @date 2022/12/6 12:14
	 * @version 1.0
	 */
	public static void main(String[] args) {
		log.info("RedisDemoApplication 开始启动...");
		long startTime = System.currentTimeMillis();
		SpringApplication.run(RedisDemoApplication.class, args);
		log.info("RedisDemoApplication启动完成，耗时[{}]ms",System.currentTimeMillis() - startTime);
	}

}
