package com.study.redisdemo.controller.userinfo;

import com.study.redisdemo.biz.userinfo.UserInfoBiz;
import com.study.redisdemo.entity.Res;
import com.study.redisdemo.entity.userinfo.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 用户信息，用户测试mybatis的配置信息是否正确
 *
 * @author
 * @date 2022/12/6 11:53
 * @version 1.0
 */
@RestController
public class UserController {

    @Autowired
    private UserInfoBiz userInfoBiz;

    /**
     * 查询所有的用户信息
     * http://127.0.0.1:8088/api/v1/userinfo/queryALlUserInfos
     * @author
     * @date 2022/12/6 11:55
     * @version 1.0
     */
    @GetMapping("/api/v1/userinfo/queryALlUserInfos")
    public List<UserInfo> queryALlUserInfos(){
        return userInfoBiz.queryAllUserInfos();
    }

    /**
     * 将所有的用户信息保存到Redis数据库中
     *
     * 触发命令：
     * curl -X POST  http://127.0.0.1:8088/api/v1/userinfo/saveAllUserInfo2Redis
     * @author
     * @date 2022/12/6 12:38
     * @version 1.0
     */
    @PostMapping("/api/v1/userinfo/saveAllUserInfo2Redis")
    public Res<String> saveAllUserInfo2Redis(){
        return userInfoBiz.saveAllUserInfo2Redis();
    }



}


