package com.study.redisdemo.service.impl.userinfo;

import com.study.redisdemo.entity.userinfo.UserInfo;
import com.study.redisdemo.mapper.userinfo.UserInfoMapper;
import com.study.redisdemo.service.userinfo.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 * 
 * @author 
 * @date 2022/12/6 11:57
 * @version 1.0
 */
@Service
public class UserInfoServiceImpl implements UserInfoService {

    private UserInfoMapper userInfoMapper;

    /**
     * 查询所有的用户信息
     *
     * @author
     * @date 2022/12/6 11:58
     * @version 1.0
     */
    @Override
    public List<UserInfo> queryAllUserInfos(){
        return userInfoMapper.queryAllUserInfos();
    }

    @Autowired
    public void setUserInfoMapper(UserInfoMapper userInfoMapper) {
        this.userInfoMapper = userInfoMapper;
    }
}
