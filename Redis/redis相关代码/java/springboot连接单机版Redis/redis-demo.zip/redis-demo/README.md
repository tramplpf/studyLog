# gradle 管理的springboot项目来操作Redis

## 项目启动
./gradlew bootRun 
