package com.example.demo.base.base;

/**
 * 所有Controller 类都需要继承的子类
 *
 * @author lpf
 * @date 20191219
 * @version 1.0
 */
public class BaseController {

}
