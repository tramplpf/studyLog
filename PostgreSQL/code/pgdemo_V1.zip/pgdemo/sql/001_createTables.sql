create table amc_oper_log (
      tid serial,
      create_date varchar(10),
      module_code varchar(10),
      button_name varchar(32)
);

insert into amc_oper_log (create_date, module_code, button_name) values ('2022-12-20','btn01','新增');
insert into amc_oper_log (create_date, module_code, button_name) values ('2022-12-20','btn01','修改');
insert into amc_oper_log (create_date, module_code, button_name) values ('2022-12-20','btn01','删除');