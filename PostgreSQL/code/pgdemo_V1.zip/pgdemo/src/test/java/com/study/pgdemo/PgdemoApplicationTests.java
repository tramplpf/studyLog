package com.study.pgdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PgdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
