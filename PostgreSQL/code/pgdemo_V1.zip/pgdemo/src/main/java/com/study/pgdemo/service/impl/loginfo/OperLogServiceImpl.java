package com.study.pgdemo.service.impl.loginfo;

import com.study.pgdemo.entity.loginfo.OperLog;
import com.study.pgdemo.mapper.operlog.OperLogMapper;
import com.study.pgdemo.service.loginfo.OperLogService;

import cn.hutool.core.date.DateUtil;
import cn.hutool.json.JSONUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * 操作日志
 *
 * @author
 * @date 2022/12/19 22:49
 * @version 1.0
 */
@Service
public class OperLogServiceImpl implements OperLogService {

    @Autowired
    private OperLogMapper operLogMapper;
    private static final Logger log = LoggerFactory.getLogger(OperLogServiceImpl.class);

    /**
     * 查询操作日志
     *
     * @param createDateStart 创建日期-起
     * @param createDateEnd   创建日期-止
     * @param moduleCode      模块编码
     * @param buttonName      按钮名称
     * @author lipf
     * @date 2022/12/19 22:46
     * @version 1.0
     */
    @Override
    public List<OperLog> queryLoginInfo(String createDateStart, String createDateEnd, String moduleCode, String buttonName) {
        return operLogMapper.queryOperByCreateDate(createDateStart,createDateEnd);
    }

    /**
     * 查询序列的下一个值
     * 
     * @author lpf
     * @date 2022年12月25日23:17:08
     * @return
     */
    @Override
    public Long queryOperlogNextSeq() {
    	return operLogMapper.queryOperlogNextSeq();
    }
    
    /**
     * 查询序列的当前值
     * 
     * @author lpf
     * @date 2022年12月25日23:17:20
     * @return
     */
    @Override
    public Long queryOperlogCurrSeq() {
    	return operLogMapper.queryOperlogCurrSeq();
    }

    /**
     * 保存操作日志
     *    注意：1.pg数据库的字段是区分大小写的
     *    2. insert 语句中需要有指定tid，并且指定序列值  
     *  
     * @author lifp
     * @date 2022年12月26日00:03:17
     */
	@Override
	public Long saveOperLog(OperLog operlog) {
		log.info("新增操作日志：operlog = [{}]", JSONUtil.toJsonPrettyStr(operlog));
		if(operlog == null) {
			return -1L;
		}
		operlog.setCreateDate(DateUtil.today());
		operlog.setCreateTime(new Date());
		operLogMapper.saveoperLog(operlog);
		log.info("pg数据库新增后，返回的主键是：[{}]",operlog.getTid());
		return operlog.getTid();
	}
	
    /**
     * 新增操作日志，不需要返回主键值
     * @param log
     */
	@Override
	public void saveOperlogWithoutTid(OperLog operlog) {
		log.info("新增操作日志：operlog = [{}]", JSONUtil.toJsonPrettyStr(operlog));
		if(operlog == null) {
			return;
		}
		operlog.setCreateDate(DateUtil.today());
		operlog.setCreateTime(new Date());
		operLogMapper.saveOperlogWithoutTid(operlog);
		
	}
}
