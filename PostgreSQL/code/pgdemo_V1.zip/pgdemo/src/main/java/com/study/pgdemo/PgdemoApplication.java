package com.study.pgdemo;

import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 启动类
 *  这个项目是自己学习Postgres数据库的demo
 *
 * @author
 * @date 2022/12/19 22:16
 * @version 1.0
 */
@MapperScan(basePackages = "com.study.pgdemo.mapper")
@SpringBootApplication
public class PgdemoApplication {


	private static final Logger log  = LoggerFactory.getLogger(PgdemoApplication.class);

	/**
	 *
	 *
	 * @author
	 * @date 2022/12/19 22:17
	 * @version 1.0
	 */
	public static void main(String[] args) {
		log.info("PG springboot 项目启动start...");
		long startTime = System.currentTimeMillis();
		SpringApplication.run(PgdemoApplication.class, args);
		long costTime = System.currentTimeMillis() - startTime;
		log.info("PG springboot 项目启动完成。costTime = [{}]ms", costTime);
	}

}
