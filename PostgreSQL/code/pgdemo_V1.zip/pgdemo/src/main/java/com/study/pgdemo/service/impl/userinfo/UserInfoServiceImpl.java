package com.study.pgdemo.service.impl.userinfo;

import com.study.pgdemo.service.UserInfoService;
import org.springframework.stereotype.Service;

/**
 *
 * 
 * @author 
 * @date 2022/12/19 22:16
 * @version 1.0
 */
@Service
public class UserInfoServiceImpl implements UserInfoService {
}
