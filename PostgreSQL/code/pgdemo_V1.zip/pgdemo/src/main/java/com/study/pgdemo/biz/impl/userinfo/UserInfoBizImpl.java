package com.study.pgdemo.biz.impl.userinfo;

import com.study.pgdemo.biz.userinfo.UserInfoBiz;
import org.springframework.stereotype.Service;

@Service
public class UserInfoBizImpl implements UserInfoBiz {


}
