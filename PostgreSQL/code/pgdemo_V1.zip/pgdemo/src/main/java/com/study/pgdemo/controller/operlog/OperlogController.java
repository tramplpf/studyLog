package com.study.pgdemo.controller.operlog;

import com.study.pgdemo.biz.OperlogBiz;
import com.study.pgdemo.entity.loginfo.OperLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 操作日志相关
 *
 * @author lipf
 * @date 2022/12/19 22:19
 * @version 1.0
 */
@RestController
public class OperlogController {

    @Autowired
    private OperlogBiz logInfoBiz;
    private static final Logger log = LoggerFactory.getLogger(OperlogController.class);

    /**
     * 测试
     * curl -X GET http://127.0.0.1:8080/api/v1/operlog/hello
     *
     * @author
     * @date 2022/12/19 23:24
     * @version 1.0
     */
    @GetMapping("/api/v1/operlog/hello")
    public String hello(){
        return "hello world! 当前时间是： " + LocalDateTime.now();
    }
    
    /**
     * 健康检查，看看程序是否正常运行
     * 
     * curl http://127.0.0.1:8080/healthCheck
     * @author lpf
     * @date 2022年12月26日00:09:33
     */
    @GetMapping("healthCheck")
    public String healthCheck() {
    	return "Hello ! 当前时间是：" + LocalDateTime.now();
    }

    /**
     * 查询操作日志
     * curl -X GET http://127.0.0.1:8080/api/v1/operlog/queryOperlogs/1/4
     * @author
     * @date 2022/12/19 22:52
     * @version 1.0
     */
    @GetMapping("/api/v1/operlog/queryOperlogs/{pageNo}/{pageSize}")
    List<OperLog> queryOperlogs(@PathVariable("pageNo") Integer pageNo,
                                @PathVariable("pageSize") Integer pageSize,
                                String createDateStart, String createDateEnd,
                                String moduleCode, String buttonName){
        log.info("pageNo = [{}],pageSize = [{}], createDateStart = [{}], createDateEnd = [{}], moduleCode = [{}], buttonName=[{}]",
                pageNo,pageSize, createDateStart, createDateEnd, moduleCode, buttonName);
        return logInfoBiz.queryOperlogs(createDateStart,createDateEnd, moduleCode, buttonName);
    }
    
    /**
     * 查询pg数据库中序列的下一个取值
     * 
     * curl -X GET http://127.0.0.1:8080/api/v1/operlog/queryOperlogNextSeq
     * 
     * @author lipf
     * @date 2022年12月25日23:14:18
     * @return
     */
    @GetMapping("/api/v1/operlog/queryOperlogNextSeq")
    public Long queryOperlogNextSeq() {
    	return logInfoBiz.queryOperlogNextSeq();
    }
    
    /**
     * 查询pg数据库中序列的当前值
     * 
     * curl -X GET http://127.0.0.1:8080/api/v1/operlog/queryOperlogCurrSeq
     * 
     * @author lipf
     * @date 2022年12月25日23:14:18
     * @return
     */
    @GetMapping("/api/v1/operlog/queryOperlogCurrSeq")
    public Long queryOperlogCurrSeq() {
    	return logInfoBiz.queryOperlogCurrSeq();
    }
    
    
    /**
     * 新增操作日志
     * curl -X POST http://127.0.0.1:8080/api/v1/operlog/saveOperlog
     * 
     * @author lipf
     * @date 2022年12月25日23:57:53
     * @param operlog
     * @return
     */
//    @PostMapping("/api/v1/operlog/saveOperlog")
//    public Long saveOperLog(@RequestBody OperLog operlog) {
//    	return logInfoBiz.saveOperLog(operlog);
//    	
//    }
    
    /**
     * 保存一个操作日志
     *  curl -X POST http://127.0.0.1:8080/api/v1/operlog/saveDefaultOperlog
     * 
     * @author lpf
     * @date 2022年12月26日00:24:08
     * @return
     */
    @PostMapping("/api/v1/operlog/saveDefaultOperlog")
    public Long saveDefaultOperlog() {
    	OperLog operlog = new OperLog();
    	operlog.setButtonName("新增");
    	operlog.setModuleCode("001");
    	operlog.setMemo("默认的操作日志，测试使用");
    	return logInfoBiz.saveOperLog(operlog);
    }

}
