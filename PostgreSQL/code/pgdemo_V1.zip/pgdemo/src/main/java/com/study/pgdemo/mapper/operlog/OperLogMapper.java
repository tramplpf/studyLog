package com.study.pgdemo.mapper.operlog;

import com.study.pgdemo.entity.loginfo.OperLog;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 操作日志
 *
 * @author
 * @date 2022/12/19 22:50
 * @version 1.0
 */
public interface OperLogMapper {

    /**
     * 查询操作日志
     *
     * @param createDateStart
     * @param createDateEnd
     * @author
     * @date 2022/12/19 23:08
     * @version 1.0
     */
    List<OperLog> queryOperByCreateDate(@Param("createDateStart") String createDateStart,
                                        @Param("createDateEnd") String createDateEnd);
    
    /**
     * 查询序列的下一个值
     * @return
     */
    Long queryOperlogNextSeq();
    
    /**
     * 查询序列的当前值
     * 
     * @return
     */
    Long queryOperlogCurrSeq();

    /**
     * 保存操作日志 
     * 
     * @author lipf
     * @date 2022年12月25日23:48:04
     * @param operlog
     */
	void saveoperLog(OperLog operlog);
	
	 /**
     * 保存操作日志 
     * 
     * @author lipf
     * @date 2022年12月25日23:48:04
     * @param operlog
     */
	void saveOperlogWithoutTid(OperLog operlog);

}
