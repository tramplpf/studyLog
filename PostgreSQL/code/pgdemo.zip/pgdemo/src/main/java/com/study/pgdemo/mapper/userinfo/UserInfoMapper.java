package com.study.pgdemo.mapper.userinfo;

import org.springframework.stereotype.Repository;

@Repository
public interface UserInfoMapper {


}
