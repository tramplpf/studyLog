package com.study.pgdemo.service.impl.loginfo;

import com.study.pgdemo.entity.loginfo.OperLog;
import com.study.pgdemo.mapper.operlog.OperLogMapper;
import com.study.pgdemo.service.loginfo.OperLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 操作日志
 *
 * @author
 * @date 2022/12/19 22:49
 * @version 1.0
 */
@Service
public class OperLogServiceImpl implements OperLogService {

    @Autowired
    private OperLogMapper operLogMapper;

    /**
     * 查询操作日志
     *
     * @param createDateStart 创建日期-起
     * @param createDateEnd   创建日期-止
     * @param moduleCode      模块编码
     * @param buttonName      按钮名称
     * @author lipf
     * @date 2022/12/19 22:46
     * @version 1.0
     */
    @Override
    public List<OperLog> queryLoginInfo(String createDateStart, String createDateEnd, String moduleCode, String buttonName) {
        return operLogMapper.queryOperByCreateDate(createDateStart,createDateEnd);
    }
}
