package com.study.pgdemo.service;

/**
 *
 * 
 * @author 
 * @date 2022/12/19 22:13
 * @version 1.0
 */
public interface UserInfoService {
}
