package com.study.pgdemo.biz.impl.loginfo;

import com.study.pgdemo.biz.OperlogBiz;
import com.study.pgdemo.entity.loginfo.OperLog;
import com.study.pgdemo.service.loginfo.OperLogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 *
 * @author
 * @date 2022/12/19 22:45
 * @version 1.0
 */
@Service
public class OperlogBizImpl implements OperlogBiz {

    private static final Logger log = LoggerFactory.getLogger(OperlogBizImpl.class);

    @Autowired
    private OperLogService operLogService;

    /**
     * 查询操作日志
     *
     * @param createDateStart 创建日期-起
     * @param createDateEnd 创建日期-止
     * @param moduleCode 模块编码
     * @param buttonName 按钮名称
     * @author lipf
     * @date 2022/12/19 22:46
     * @version 1.0
     */
    @Override
    public List<OperLog> queryOperlogs(String createDateStart, String createDateEnd, String moduleCode, String buttonName) {
        log.info("查询操作日志：createDateStart=[{}],createDateEnd = [{}],moduleCode = [{}],buttonName = [{}]",createDateStart,createDateEnd, moduleCode, buttonName);
        List<OperLog> operLogs = operLogService.queryLoginInfo(createDateStart, createDateEnd, moduleCode, buttonName);
        if (log.isDebugEnabled()) {
            log.info("查询操作日志：createDateStart=[{}],createDateEnd = [{}],moduleCode = [{}],buttonName = [{}]",createDateStart,createDateEnd, moduleCode, buttonName);
        }
        return operLogs;
    }
}
