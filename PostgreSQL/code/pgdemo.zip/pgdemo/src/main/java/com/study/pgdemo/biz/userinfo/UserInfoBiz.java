package com.study.pgdemo.biz.userinfo;

/**
 *
 *
 * @author
 * @date 2022/12/19 22:12
 * @version 1.0
 */
public interface UserInfoBiz {

}
