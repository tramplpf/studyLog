package com.study.pgdemo.entity.loginfo;

import java.io.Serializable;
import java.util.Date;

/**
 *
 *
 * @author
 * @date 2022/12/19 22:20
 * @version 1.0
 */
public class OperLog implements Serializable {

    /**
     * 序号
     */
    private Long tid;

    /**
     * 创建日期
     */
    private String createDate;

    /**
     * 模块名称
     */
    private String moduleCode;

    /**
     * 按钮名称
     */
    private String buttonName;

    /**
     * 创建时间
     *
     */
    private Date createTime;

    public Long getTid() {
        return tid;
    }

    public void setTid(Long tid) {
        this.tid = tid;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getModuleCode() {
        return moduleCode;
    }

    public void setModuleCode(String moduleCode) {
        this.moduleCode = moduleCode;
    }

    public String getButtonName() {
        return buttonName;
    }

    public void setButtonName(String buttonName) {
        this.buttonName = buttonName;
    }
}
