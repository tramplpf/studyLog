package com.study.pgdemo.controller.operlog;

import com.study.pgdemo.biz.OperlogBiz;
import com.study.pgdemo.entity.loginfo.OperLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 操作日志相关
 *
 * @author lipf
 * @date 2022/12/19 22:19
 * @version 1.0
 */
@RestController
public class OperlogController {

    @Autowired
    private OperlogBiz logInfoBiz;
    private static final Logger log = LoggerFactory.getLogger(OperlogController.class);

    /**
     * 测试
     * curl -X GET http://127.0.0.1:8080/api/v1/operlog/hello
     *
     * @author
     * @date 2022/12/19 23:24
     * @version 1.0
     */
    @GetMapping("/api/v1/operlog/hello")
    public String hello(){
        return "hello world! 当前时间是： " + LocalDateTime.now();
    }

    /**
     * 查询操作日志
     * curl -X GET http://127.0.0.1:8080/api/v1/operlog/queryOperlogs/1/4
     * @author
     * @date 2022/12/19 22:52
     * @version 1.0
     */
    @GetMapping("/api/v1/operlog/queryOperlogs/{pageNo}/{pageSize}")
    List<OperLog> queryOperlogs(@PathVariable("pageNo") Integer pageNo,
                                @PathVariable("pageSize") Integer pageSize,
                                String createDateStart, String createDateEnd,
                                String moduleCode, String buttonName){
        log.info("pageNo = [{}],pageSize = [{}], createDateStart = [{}], createDateEnd = [{}], moduleCode = [{}], buttonName=[{}]",
                pageNo,pageSize, createDateStart, createDateEnd, moduleCode, buttonName);
        return logInfoBiz.queryOperlogs(createDateStart,createDateEnd, moduleCode, buttonName);
    }

}
