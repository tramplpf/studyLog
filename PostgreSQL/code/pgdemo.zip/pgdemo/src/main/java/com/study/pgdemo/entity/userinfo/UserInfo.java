package com.study.pgdemo.entity.userinfo;

import java.io.Serializable;

/**
 * 用户信息
 *
 *
 * @author
 * @date 2022/12/19 22:14
 * @version 1.0
 */
public class UserInfo implements Serializable {
}
